from django.apps import AppConfig


class SemperNewsAppConfig(AppConfig):
    name = 'SemperNewsApp'
